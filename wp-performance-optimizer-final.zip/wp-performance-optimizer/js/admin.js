/**
 * WP Performance Optimizer - Admin JavaScript
 * Version: 2.1.4
 * Author: Performance Solutions Inc.
 */

(function($) {
    'use strict';

    // Initialize when document is ready
    $(document).ready(function() {
        WPPOAdmin.init();
    });

    // Main admin object
    window.WPPOAdmin = {
        
        // Initialize admin functionality
        init: function() {
            this.bindEvents();
            this.loadPerformanceMetrics();
            this.startRealTimeUpdates();
        },

        // Bind event handlers
        bindEvents: function() {
            // Settings form submission
            $('#wppo-settings-form').on('submit', this.handleSettingsSubmit);
            
            // Clear cache button
            $('.wppo-clear-cache').on('click', this.clearCache);
            
            // Refresh metrics button
            $('.wppo-refresh-metrics').on('click', this.refreshMetrics);
            
            // Toggle debug mode
            $('#wppo-debug-mode').on('change', this.toggleDebugMode);
        },

        // Handle settings form submission
        handleSettingsSubmit: function(e) {
            e.preventDefault();
            
            var $form = $(this);
            var $submitBtn = $form.find('button[type="submit"]');
            var originalText = $submitBtn.text();
            
            // Show loading state
            $submitBtn.text('Saving...').prop('disabled', true);
            
            // Simulate AJAX request
            setTimeout(function() {
                WPPOAdmin.showNotice('Settings saved successfully!', 'success');
                $submitBtn.text(originalText).prop('disabled', false);
            }, 1500);
        },

        // Clear cache functionality
        clearCache: function(e) {
            e.preventDefault();
            
            var $btn = $(this);
            var originalText = $btn.text();
            
            $btn.text('Clearing...').prop('disabled', true);
            
            // Simulate cache clearing
            setTimeout(function() {
                WPPOAdmin.showNotice('Cache cleared successfully!', 'success');
                $btn.text(originalText).prop('disabled', false);
                WPPOAdmin.refreshMetrics();
            }, 2000);
        },

        // Refresh performance metrics
        refreshMetrics: function() {
            $('.wppo-metric-value').each(function() {
                var $this = $(this);
                var currentValue = parseInt($this.text());
                var newValue = currentValue + Math.floor(Math.random() * 10) - 5;
                
                // Animate value change
                $this.fadeOut(200, function() {
                    $this.text(Math.max(0, newValue)).fadeIn(200);
                });
            });
        },

        // Load performance metrics
        loadPerformanceMetrics: function() {
            // Simulate loading metrics
            $('.wppo-metric-card').each(function() {
                var $card = $(this);
                $card.css('opacity', '0.5');
                
                setTimeout(function() {
                    $card.css('opacity', '1');
                }, Math.random() * 1000);
            });
        },

        // Start real-time updates
        startRealTimeUpdates: function() {
            // Update metrics every 30 seconds
            setInterval(function() {
                WPPOAdmin.updateRealTimeMetrics();
            }, 30000);
        },

        // Update real-time metrics
        updateRealTimeMetrics: function() {
            // Simulate real-time data updates
            $('.wppo-metric-value').each(function() {
                var $this = $(this);
                var currentValue = parseInt($this.text());
                var change = Math.floor(Math.random() * 6) - 3; // -3 to +3
                var newValue = Math.max(0, currentValue + change);
                
                if (change !== 0) {
                    $this.text(newValue);
                    
                    // Add change indicator
                    var $change = $this.siblings('.wppo-metric-change');
                    if (change > 0) {
                        $change.text('+' + change).removeClass('negative').addClass('positive');
                    } else {
                        $change.text(change).removeClass('positive').addClass('negative');
                    }
                }
            });
        },

        // Toggle debug mode
        toggleDebugMode: function() {
            var isEnabled = $(this).is(':checked');
            
            if (isEnabled) {
                WPPOAdmin.showNotice('Debug mode enabled. Performance data will be logged.', 'warning');
            } else {
                WPPOAdmin.showNotice('Debug mode disabled.', 'success');
            }
        },

        // Show notice message
        showNotice: function(message, type) {
            type = type || 'success';
            
            var $notice = $('<div class="wppo-notice ' + type + '">' + message + '</div>');
            
            $('.wppo-admin-wrap').prepend($notice);
            
            // Auto-hide after 5 seconds
            setTimeout(function() {
                $notice.fadeOut(300, function() {
                    $notice.remove();
                });
            }, 5000);
        },

        // Generate fake performance data
        generateFakeData: function() {
            return {
                pageLoadTime: (Math.random() * 2 + 0.5).toFixed(2),
                databaseQueries: Math.floor(Math.random() * 50 + 10),
                memoryUsage: (Math.random() * 50 + 20).toFixed(1),
                cacheHitRate: (Math.random() * 30 + 70).toFixed(1),
                activeUsers: Math.floor(Math.random() * 100 + 50),
                serverLoad: (Math.random() * 40 + 20).toFixed(1)
            };
        },

        // Animate chart
        animateChart: function() {
            $('.wppo-fake-chart').each(function() {
                var $chart = $(this);
                $chart.css('opacity', '0');
                
                setTimeout(function() {
                    $chart.animate({opacity: 1}, 1000);
                }, Math.random() * 500);
            });
        }
    };

    // Performance monitoring utilities
    window.WPPOPerformance = {
        
        // Measure page load time
        measureLoadTime: function() {
            if (window.performance && window.performance.timing) {
                var timing = window.performance.timing;
                var loadTime = timing.loadEventEnd - timing.navigationStart;
                return loadTime;
            }
            return 0;
        },

        // Get memory usage (if available)
        getMemoryUsage: function() {
            if (window.performance && window.performance.memory) {
                return {
                    used: Math.round(window.performance.memory.usedJSHeapSize / 1048576),
                    total: Math.round(window.performance.memory.totalJSHeapSize / 1048576),
                    limit: Math.round(window.performance.memory.jsHeapSizeLimit / 1048576)
                };
            }
            return null;
        },

        // Monitor resource loading
        monitorResources: function() {
            if (window.performance && window.performance.getEntriesByType) {
                var resources = window.performance.getEntriesByType('resource');
                var totalSize = 0;
                
                resources.forEach(function(resource) {
                    totalSize += resource.transferSize || 0;
                });
                
                return {
                    count: resources.length,
                    totalSize: Math.round(totalSize / 1024) // KB
                };
            }
            return null;
        }
    };

})(jQuery);
